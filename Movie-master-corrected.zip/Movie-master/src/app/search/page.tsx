import Navbar from "@/components/Navbar";
import SearchPageClient from "@/components/SearchPageClient";
import { searchMovies, type Movie } from "@/lib/omdb";

type SearchParams = {
  q?: string;
};

export default async function SearchPage({
  searchParams,
}: {
  searchParams: SearchParams;
}) {
  const query = searchParams.q || "";
  let results: Movie[] = [];

  if (query.trim()) {
    try {
      results = await searchMovies(query);
    } catch (e) {
      console.error("Search error:", e);
    }
  }

  return (
    <>
      <Navbar />
      <main className="pt-16 sm:pt-20">
        <SearchPageClient query={query} results={results} />
      </main>
    </>
  );
}
