import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Movies — Netflix-style",
  description: "Search and discover movies powered by the OMDb API",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-netflix-black">{children}</body>
    </html>
  );
}
