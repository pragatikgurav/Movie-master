import Navbar from "@/components/Navbar";
import HeroBillboard from "@/components/HeroBillboard";
import MoviePageClient from "@/components/MoviePageClient";
import {
  fetchTrending,
  fetchTopRated,
  getMovieById,
  type Movie,
} from "@/lib/omdb";

export default async function Home() {
  let trending: Movie[] = [];
  let topRated: Movie[] = [];
  let heroMovie: Movie | null = null;

  try {
    [trending, topRated] = await Promise.all([
      fetchTrending(),
      fetchTopRated(),
    ]);
    const first = trending[0] ?? topRated[0];
    if (first) {
      const details = await getMovieById(first.id);
      heroMovie = details ?? first;
    }
  } catch (e) {
    console.error("OMDB fetch error:", e);
  }

  return (
    <>
      <Navbar />
      <main className="pt-0">
        <MoviePageClient
          heroMovie={heroMovie}
          trending={trending}
          topRated={topRated}
        />
      </main>
    </>
  );
}
