/**
 * OMDb API client.
 *
 * Required environment variable:
 * NEXT_PUBLIC_OMDB_API_KEY=your_api_key
 */

const OMDB_BASE = "https://www.omdbapi.com";

export type Movie = {
  id: string;
  title: string;
  poster_path: string | null;
  backdrop_path: string | null;
  overview: string;
  year?: string;
};

type SearchResult = {
  Title: string;
  Year: string;
  imdbID: string;
  Type: string;
  Poster: string;
};

type SearchResponse = {
  Search?: SearchResult[];
  totalResults?: string;
  Response: "True" | "False";
  Error?: string;
};

type DetailResponse = {
  Title: string;
  Year: string;
  Plot: string;
  Poster: string;
  imdbID: string;
  Response: "True" | "False";
  Error?: string;
};

function getApiKey(): string {
  const key = process.env.NEXT_PUBLIC_OMDB_API_KEY?.trim();

  if (!key || key === "your_omdb_api_key_here") {
    throw new Error(
      "Missing NEXT_PUBLIC_OMDB_API_KEY. Add a valid OMDb API key to .env.local."
    );
  }

  return key;
}

async function fetchOmdb<T>(params: Record<string, string>): Promise<T> {
  const key = getApiKey();
  const searchParams = new URLSearchParams({ apikey: key, ...params });

  const response = await fetch(`${OMDB_BASE}/?${searchParams.toString()}`, {
    next: { revalidate: 3600 },
  });

  if (!response.ok) {
    throw new Error(`OMDb request failed with status ${response.status}.`);
  }

  return response.json() as Promise<T>;
}

function mapSearchToMovie(movie: SearchResult): Movie {
  return {
    id: movie.imdbID,
    title: movie.Title,
    poster_path:
      movie.Poster && movie.Poster !== "N/A" ? movie.Poster : null,
    backdrop_path: null,
    overview: "",
    year: movie.Year,
  };
}

export async function searchMovies(
  query: string,
  page = 1
): Promise<Movie[]> {
  const cleanQuery = query.trim();

  if (!cleanQuery) {
    return [];
  }

  const data = await fetchOmdb<SearchResponse>({
    s: cleanQuery,
    type: "movie",
    page: String(Math.max(1, page)),
  });

  if (data.Response !== "True" || !data.Search) {
    return [];
  }

  return data.Search
    .filter((movie) => movie.Poster && movie.Poster !== "N/A")
    .map(mapSearchToMovie);
}

export async function getMovieById(imdbId: string): Promise<Movie | null> {
  const id = imdbId.trim();

  if (!id) {
    return null;
  }

  const data = await fetchOmdb<DetailResponse>({
    i: id,
  });

  if (data.Response !== "True" || !data.imdbID) {
    return null;
  }

  return {
    id: data.imdbID,
    title: data.Title,
    poster_path:
      data.Poster && data.Poster !== "N/A" ? data.Poster : null,
    backdrop_path:
      data.Poster && data.Poster !== "N/A" ? data.Poster : null,
    overview: data.Plot && data.Plot !== "N/A" ? data.Plot : "",
    year: data.Year,
  };
}

/**
 * OMDb does not provide a real "trending" endpoint.
 * These search terms are used as simple homepage categories.
 */
export async function fetchTrending(): Promise<Movie[]> {
  return searchMovies("2024");
}

export async function fetchTopRated(): Promise<Movie[]> {
  return searchMovies("action");
}

export function getImageUrl(posterUrl: string | null): string {
  if (!posterUrl || posterUrl === "N/A") {
    return "/placeholder-poster.svg";
  }

  return posterUrl;
}

export function getMovieTitle(movie: Movie): string {
  return movie.title || "Unknown";
}

/**
 * Returns a demo video until a real movie-video service is connected.
 * If NEXT_PUBLIC_VIDEO_CDN_BASE_URL is set, the movie is loaded from:
 * <base-url>/<imdb-id>.mp4
 */
export function getVideoUrl(imdbId: string): string | null {
  const baseUrl = process.env.NEXT_PUBLIC_VIDEO_CDN_BASE_URL?.trim();

  if (baseUrl) {
    return `${baseUrl.replace(/\/+$/, "")}/${encodeURIComponent(imdbId)}.mp4`;
  }

  return "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4";
}
