"use client";

import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

type VideoPlayerProps = {
  videoUrl: string | null;
  movieTitle: string;
  isOpen: boolean;
  onClose: () => void;
};

export default function VideoPlayer({
  videoUrl,
  movieTitle,
  isOpen,
  onClose,
}: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen && videoRef.current) {
      setIsLoading(true);
      setError(null);
      videoRef.current.load();
    }
  }, [isOpen, videoUrl]);

  useEffect(() => {
    if (!isOpen && videoRef.current) {
      videoRef.current.pause();
      videoRef.current.currentTime = 0;
    }
  }, [isOpen]);

  const handleLoadedData = () => {
    setIsLoading(false);
    setError(null);
  };

  const handleError = (e: React.SyntheticEvent<HTMLVideoElement, Event>) => {
    setIsLoading(false);
    const video = e.currentTarget;
    let errorMessage = "Failed to load video.";
    
    if (video.error) {
      switch (video.error.code) {
        case video.error.MEDIA_ERR_ABORTED:
          errorMessage = "Video loading was aborted.";
          break;
        case video.error.MEDIA_ERR_NETWORK:
          errorMessage = "Network error. Check your connection and CORS settings.";
          break;
        case video.error.MEDIA_ERR_DECODE:
          errorMessage = "Video codec error. The format may not be supported.";
          break;
        case video.error.MEDIA_ERR_SRC_NOT_SUPPORTED:
          errorMessage = "Video format not supported or CORS issue. Check the video URL.";
          break;
        default:
          errorMessage = "Failed to load video. Please check the video URL or CORS configuration.";
      }
    }
    
    setError(errorMessage);
  };

  useEffect(() => {
    if (!isOpen) return;

    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        onClose();
      }
    };

    document.addEventListener("keydown", handleEscape);
    return () => document.removeEventListener("keydown", handleEscape);
  }, [isOpen, onClose]);

  // Generate a demo video URL if none provided
  // In production, this would come from your video service/CDN
  const getVideoSource = () => {
    if (videoUrl) return videoUrl;
    
    // Demo: Using a sample video URL (Big Buck Bunny - public domain)
    // Replace this with your actual video CDN/service
    return "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4";
  };

  const videoSource = getVideoSource();
  const isHls = videoSource.includes('.m3u8');

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/95 z-[100] flex items-center justify-center"
            onClick={onClose}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full h-full max-w-7xl max-h-[90vh] flex flex-col p-4 sm:p-6 md:p-8"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Close button */}
              <button
                onClick={onClose}
                className="absolute top-4 right-4 z-10 bg-black/70 hover:bg-black/90 rounded-full p-2 transition-colors"
                aria-label="Close video player"
              >
                <svg
                  className="w-6 h-6 text-white"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M6 18L18 6M6 6l12 12"
                  />
                </svg>
              </button>

              {/* Video container */}
              <div className="flex-1 relative bg-black rounded-lg overflow-hidden">
                {isLoading && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-netflix-red"></div>
                  </div>
                )}

                {error && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center p-8">
                    <svg
                      className="w-16 h-16 text-white/50 mb-4"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                      />
                    </svg>
                    <p className="text-white/90 text-center mb-2">{error}</p>
                    <p className="text-white/60 text-sm text-center">
                      {movieTitle}
                    </p>
                  </div>
                )}

                <video
                  ref={videoRef}
                  className="w-full h-full object-contain"
                  controls
                  playsInline
                  onLoadedData={handleLoadedData}
                  onError={(e) => handleError(e)}
                  crossOrigin="anonymous"
                  preload="metadata"
                >
                  {isHls ? (
                    <source src={videoSource} type="application/x-mpegURL" />
                  ) : (
                    <source src={videoSource} type="video/mp4" />
                  )}
                  Your browser does not support the video tag.
                </video>
              </div>

              {/* Movie title */}
              <div className="mt-4 text-center">
                <h2 className="text-xl sm:text-2xl font-bold text-white">
                  {movieTitle}
                </h2>
              </div>
            </motion.div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
