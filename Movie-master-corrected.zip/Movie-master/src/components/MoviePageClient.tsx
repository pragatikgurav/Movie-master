"use client";

import { useState } from "react";
import HeroBillboard from "@/components/HeroBillboard";
import MovieRow from "@/components/MovieRow";
import VideoPlayer from "@/components/VideoPlayer";
import { getVideoUrl, type Movie } from "@/lib/omdb";

type Props = {
  heroMovie: Movie | null;
  trending: Movie[];
  topRated: Movie[];
};

export default function MoviePageClient({
  heroMovie,
  trending,
  topRated,
}: Props) {
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);
  const [isPlayerOpen, setIsPlayerOpen] = useState(false);

  const handleMovieClick = (movie: Movie) => {
    setSelectedMovie(movie);
    setIsPlayerOpen(true);
  };

  const handleClosePlayer = () => {
    setIsPlayerOpen(false);
    setSelectedMovie(null);
  };

  return (
    <>
      {heroMovie && (
        <HeroBillboard movie={heroMovie} onPlayClick={handleMovieClick} />
      )}
      {!heroMovie && (
        <section className="h-[45vh] min-h-[280px] flex items-center justify-center bg-netflix-dark">
          <p className="text-white/70 text-center px-4">
            Add <code className="bg-white/10 px-1 rounded">NEXT_PUBLIC_OMDB_API_KEY</code> to{" "}
            <code className="bg-white/10 px-1 rounded">.env.local</code> and restart.
          </p>
        </section>
      )}
      {trending.length > 0 && (
        <MovieRow
          id="trending"
          title="Trending"
          movies={trending}
          onMovieClick={handleMovieClick}
        />
      )}
      {topRated.length > 0 && (
        <MovieRow
          id="top-rated"
          title="Top Rated"
          movies={topRated}
          onMovieClick={handleMovieClick}
        />
      )}
      <VideoPlayer
        videoUrl={selectedMovie ? getVideoUrl(selectedMovie.id) : null}
        movieTitle={selectedMovie ? selectedMovie.title : ""}
        isOpen={isPlayerOpen}
        onClose={handleClosePlayer}
      />
    </>
  );
}
