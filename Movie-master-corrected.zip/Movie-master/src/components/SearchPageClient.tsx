"use client";

import { useState } from "react";
import MovieRow from "@/components/MovieRow";
import VideoPlayer from "@/components/VideoPlayer";
import { getVideoUrl, type Movie } from "@/lib/omdb";

type Props = {
  query: string;
  results: Movie[];
};

export default function SearchPageClient({ query, results }: Props) {
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);
  const [isPlayerOpen, setIsPlayerOpen] = useState(false);

  const handleMovieClick = (movie: Movie) => {
    setSelectedMovie(movie);
    setIsPlayerOpen(true);
  };

  const handleClosePlayer = () => {
    setIsPlayerOpen(false);
    setSelectedMovie(null);
  };

  return (
    <>
      {query ? (
        <>
          <div className="px-4 sm:px-6 md:px-8 py-6 sm:py-8">
            <h1 className="text-2xl sm:text-3xl font-bold mb-2">
              Search Results
            </h1>
            <p className="text-white/70 text-sm sm:text-base">
              Found {results.length} result{results.length !== 1 ? "s" : ""} for &quot;{query}&quot;
            </p>
          </div>
          {results.length > 0 ? (
            <MovieRow
              id="search-results"
              title=""
              movies={results}
              onMovieClick={handleMovieClick}
            />
          ) : (
            <div className="px-4 sm:px-6 md:px-8 py-12 sm:py-16 text-center">
              <p className="text-white/70 text-lg">
                No movies found for &quot;{query}&quot;
              </p>
              <p className="text-white/50 text-sm mt-2">
                Try a different search term
              </p>
            </div>
          )}
        </>
      ) : (
        <div className="px-4 sm:px-6 md:px-8 py-12 sm:py-16 text-center">
          <h1 className="text-2xl sm:text-3xl font-bold mb-4">Search Movies</h1>
          <p className="text-white/70">
            Enter a search term in the search bar above
          </p>
        </div>
      )}
      <VideoPlayer
        videoUrl={selectedMovie ? getVideoUrl(selectedMovie.id) : null}
        movieTitle={selectedMovie ? selectedMovie.title : ""}
        isOpen={isPlayerOpen}
        onClose={handleClosePlayer}
      />
    </>
  );
}
