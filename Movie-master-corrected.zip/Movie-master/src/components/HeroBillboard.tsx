"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { getImageUrl, getMovieTitle, type Movie } from "@/lib/omdb";

type Props = { 
  movie: Movie;
  onPlayClick?: (movie: Movie) => void;
};

export default function HeroBillboard({ movie, onPlayClick }: Props) {
  const title = getMovieTitle(movie);
  const heroImage = getImageUrl(movie.backdrop_path ?? movie.poster_path);

  const handlePlayClick = () => {
    if (onPlayClick) {
      onPlayClick(movie);
    }
  };

  return (
    <section className="relative h-[45vh] min-h-[280px] sm:h-[55vh] md:h-[70vh] w-full overflow-hidden">
      <div className="absolute inset-0">
        {heroImage.startsWith("http") ? (
          <Image
            src={heroImage}
            alt=""
            fill
            className="object-cover"
            priority
            sizes="100vw"
          />
        ) : (
          <div className="absolute inset-0 bg-gradient-to-br from-netflix-dark to-netflix-black" />
        )}
        <div
          className="absolute inset-0 bg-gradient-to-t from-netflix-black via-netflix-black/70 to-transparent"
          aria-hidden
        />
        <div
          className="absolute inset-0 bg-gradient-to-r from-netflix-black/90 via-netflix-black/40 to-transparent"
          aria-hidden
        />
      </div>
      <div className="absolute bottom-0 left-0 right-0 p-4 sm:p-6 md:p-8 lg:p-12 max-w-2xl">
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white drop-shadow-lg mb-2">
          {title}
        </h1>
        {movie.overview && (
          <p className="text-sm sm:text-base text-white/90 line-clamp-2 sm:line-clamp-3 drop-shadow mb-4">
            {movie.overview}
          </p>
        )}
        {onPlayClick && (
          <motion.button
            onClick={handlePlayClick}
            className="flex items-center gap-2 bg-white text-netflix-black px-6 py-2.5 sm:px-8 sm:py-3 rounded-md font-semibold text-sm sm:text-base hover:bg-white/90 transition-colors"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <svg
              className="w-5 h-5 sm:w-6 sm:h-6"
              fill="currentColor"
              viewBox="0 0 20 20"
            >
              <path d="M6.3 2.841A1.5 1.5 0 004 4.11V15.89a1.5 1.5 0 002.3 1.269l9.344-5.89a1.5 1.5 0 000-2.538L6.3 2.84z" />
            </svg>
            Play
          </motion.button>
        )}
      </div>
    </section>
  );
}
