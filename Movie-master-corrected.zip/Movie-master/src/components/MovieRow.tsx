"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { getImageUrl, getMovieTitle, type Movie } from "@/lib/omdb";

type Props = {
  title: string;
  movies: Movie[];
  id?: string;
  onMovieClick?: (movie: Movie) => void;
};

const cardVariants = {
  rest: { scale: 1 },
  hover: { scale: 1.08 },
};

export default function MovieRow({ title, movies, id, onMovieClick }: Props) {
  const handleClick = (movie: Movie) => {
    if (onMovieClick) {
      onMovieClick(movie);
    }
  };

  return (
    <section id={id} className="mb-8 md:mb-10">
      {title && (
        <h2 className="text-lg sm:text-xl font-semibold mb-3 sm:mb-4 px-4 sm:px-6 md:px-8">
          {title}
        </h2>
      )}
      <div className="scroll-row flex gap-2 sm:gap-3 overflow-x-auto overflow-y-hidden pb-2 px-4 sm:px-6 md:px-8">
        {movies.map((movie) => {
          const posterUrl = getImageUrl(movie.poster_path ?? null);
          const name = getMovieTitle(movie);
          return (
            <motion.div
              key={movie.id}
              className="flex-shrink-0 w-[120px] sm:w-[140px] md:w-[160px] rounded overflow-hidden cursor-pointer"
              variants={cardVariants}
              initial="rest"
              whileHover="hover"
              transition={{ type: "tween", duration: 0.2 }}
              onClick={() => handleClick(movie)}
            >
              <div className="relative aspect-[2/3] bg-netflix-dark rounded group">
                <Image
                  src={posterUrl}
                  alt={name}
                  fill
                  className="object-cover"
                  sizes="(max-width: 640px) 120px, (max-width: 768px) 140px, 160px"
                  unoptimized={!posterUrl.startsWith("http")}
                />
                {/* Play overlay on hover */}
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors flex items-center justify-center">
                  <motion.div
                    initial={{ scale: 0, opacity: 0 }}
                    whileHover={{ scale: 1, opacity: 1 }}
                    className="bg-white/90 rounded-full p-2 sm:p-3"
                  >
                    <svg
                      className="w-4 h-4 sm:w-5 sm:h-5 text-netflix-black"
                      fill="currentColor"
                      viewBox="0 0 20 20"
                    >
                      <path d="M6.3 2.841A1.5 1.5 0 004 4.11V15.89a1.5 1.5 0 002.3 1.269l9.344-5.89a1.5 1.5 0 000-2.538L6.3 2.84z" />
                    </svg>
                  </motion.div>
                </div>
              </div>
              <p className="text-xs sm:text-sm mt-1 text-white/90 truncate px-0.5">
                {name}
              </p>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
}
