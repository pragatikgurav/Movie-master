"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { useRouter } from "next/navigation";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      router.push(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
      setSearchQuery("");
      setIsSearchFocused(false);
    }
  };

  return (
    <motion.header
      initial={false}
      animate={{
        backgroundColor: scrolled ? "rgba(20, 20, 20, 0.98)" : "rgba(0, 0, 0, 0)",
      }}
      transition={{ duration: 0.25 }}
      className="fixed top-0 left-0 right-0 z-50 px-4 sm:px-6 md:px-8 py-3 flex items-center justify-between"
    >
      <a href="/" className="text-netflix-red font-bold text-xl sm:text-2xl tracking-tight">
        MOVIES
      </a>
      <nav className="flex items-center gap-3 sm:gap-4 md:gap-6">
        <form onSubmit={handleSearch} className="relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onFocus={() => setIsSearchFocused(true)}
            onBlur={() => setTimeout(() => setIsSearchFocused(false), 200)}
            placeholder="Search movies..."
            className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-md px-3 py-1.5 sm:px-4 sm:py-2 text-sm text-white placeholder-white/60 focus:outline-none focus:border-white/40 focus:bg-white/15 transition-all w-32 sm:w-40 md:w-48 lg:w-56"
          />
          {isSearchFocused && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="absolute top-full mt-2 right-0 bg-netflix-dark border border-white/20 rounded-md shadow-lg p-2 min-w-[200px] z-50"
            >
              <p className="text-xs text-white/70 px-2 py-1">
                Press Enter to search
              </p>
            </motion.div>
          )}
        </form>
        <a
          href="#trending"
          className="text-sm text-white/90 hover:text-white transition-colors hidden sm:block"
        >
          Trending
        </a>
        <a
          href="#top-rated"
          className="text-sm text-white/90 hover:text-white transition-colors hidden sm:block"
        >
          Top Rated
        </a>
      </nav>
    </motion.header>
  );
}
