import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        netflix: {
          red: "#e50914",
          black: "#141414",
          dark: "#181818",
        },
      },
      backgroundImage: {
        "gradient-hero":
          "linear-gradient(to top, rgba(20,20,20,1) 0%, rgba(20,20,20,0.7) 20%, rgba(20,20,20,0) 60%)",
        "gradient-hero-left":
          "linear-gradient(to right, rgba(20,20,20,0.9) 0%, transparent 50%)",
      },
    },
  },
  plugins: [],
};

export default config;
